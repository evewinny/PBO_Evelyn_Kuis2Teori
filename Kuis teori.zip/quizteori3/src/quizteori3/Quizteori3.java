/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizteori3;

/**
 *
 * @author Felicia Mulia
 */
import java.awt.*;
public class Quizteori3 extends Panel{

    /**
     * @param args the command line arguments
     */
     Quizteori3() {
        setBackground(Color.white); 
    }
    
     public void paint(Graphics g) {
        // kotak atas
        g.setColor(Color.blue);
        g.fillRect(50,8,280,80);
        g.drawRect(50,8,280,80);
        //pinggiran hitam
        g.setColor(Color.BLACK);
        g.drawRect(50,8,280,80);
        // kotak bawah
        g.setColor(Color.blue);
        g.fillRect(50,80,430,110);
        g.drawRect(50,80,430,110);
        //pinggiran hitam
        g.setColor(Color.BLACK);
        g.drawRect(50,80,430,110);
        //roda 1
        g.setColor(Color.red);
        g.drawOval(100,120, 140,140);
        g.fillOval(100,120,140,140);
        //pinggiran hitam
        g.setColor(Color.BLACK);
        g.drawOval(100,120,140,140);
        //roda 2
        g.setColor(Color.red);
        g.drawOval(300,120,140,140);
        g.fillOval(300,120,140,140); 
        //pinggiran hitam
        g.setColor(Color.BLACK);
        g.drawOval(300,120,140,140);
    }
     
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Quiz 3");
        Quizteori3 gp = new Quizteori3();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}
